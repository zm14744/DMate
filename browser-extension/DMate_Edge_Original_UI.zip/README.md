DMate for Microsoft Edge
========================

Install
-------
1. Extract this ZIP to a folder.
2. Open edge://extensions in Microsoft Edge.
3. Enable Developer mode.
4. Choose Load unpacked.
5. Select this extracted folder (the folder containing manifest.json).

Click the DMate toolbar icon to open DMate in Edge's native Side Panel.

This package embeds the existing DMate website at https://dmate.zeabur.app/.
It uses the existing DMate v52 product icon assets. It does not contain a
separate replacement chat interface.

Requires Microsoft Edge 116 or later.
