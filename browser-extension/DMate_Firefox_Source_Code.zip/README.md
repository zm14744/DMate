# DMate Firefox Add-on — Source Code Submission

This archive accompanies the DMate Firefox Manifest V3 add-on submitted to Mozilla Add-ons (AMO).

## Contents

- extension/: the exact Firefox extension source tree used to build the submitted ZIP.
- original-frontend/templates-index.html: the original server-side HTML template.
- original-frontend/static/: the original first-party front-end assets and vendored browser libraries.
- vendor-packages.json: exact upstream npm package versions, registry tarball URLs, integrity values, and vendored file hashes.
- vendor-source/: official npm package archives for the vendored third-party libraries.
- SECURITY_PRIVACY.md: repository documentation describing data flows, local storage, server processing, and third-party services.
- THIRD_PARTY_LICENSES.md: third-party license inventory.

## Reproducing the package

1. Use Node.js with npm and Python 3.
2. The exact upstream dependencies are recorded in vendor-packages.json:
   - mathjax 3.2.2
   - marked 15.0.12
   - dompurify 3.2.6
   - html2canvas 1.4.1
   - jspdf 2.5.2
3. The matching official npm archives are included under vendor-source/. Their package versions and integrity values are also recorded in vendor-packages.json.
4. The extension uses the original DMate front-end resources locally. extension/sidebar.html is the extension-ready adaptation of the original template: server-side template expressions are resolved or removed, executable inline scripts are moved to local files under extension/extension/, and the API bridge routes application API requests to the declared DMate backend host.
5. The Firefox-specific integration is defined by extension/manifest.json and extension/background.js. It uses Firefox's native sidebar_action API; the application UI and first-party front-end assets are otherwise reused from the Edge package.
6. To package the exact extension tree, run:
   cd extension && zip -X -qr ../DMate_Firefox_Addon.zip .

No remote JavaScript or WebAssembly is loaded for execution. The extension's application requests go to https://dmate.zeabur.app/; the backend may forward user-submitted content to the configured AI and email providers as documented in SECURITY_PRIVACY.md.
