(function(root){
 'use strict';
const uiText=(source,english)=>root.DMateI18n?.t?.(source,english)??source;
 const clone=v=>JSON.parse(JSON.stringify(v));
 const blank=(name='我的图形')=>({body_text:'',graphs:[{id:'G1',name,directed:false,weighted:false,vertices:[],edges:[]}]});
 const emptyDocument=()=>({body_text:'',graphs:[]});
 const id=()=>root.crypto?.randomUUID?.()||'drawing-'+Date.now()+'-'+Math.random().toString(36).slice(2);
 const goodDocument=v=>v&&typeof v==='object'&&Array.isArray(v.graphs)&&v.graphs.length>0&&v.graphs.every(g=>g&&typeof g==='object'&&Array.isArray(g.vertices)&&Array.isArray(g.edges));
 const meaningfulDocument=v=>goodDocument(v)&&(String(v.body_text||'').trim()||v.graphs.some(g=>g.vertices.length||g.edges.length||String(g.name||'').trim()&&!['我的图形','图 1','图1'].includes(String(g.name).trim())));
 const caption=v=>String(v||'未命名绘图').trim().slice(0,80)||'未命名绘图';
 const fingerprint=v=>JSON.stringify(v);
 function mount(host,options={}){
  const doc=host.ownerDocument,win=doc.defaultView;
  if(!root.DMateGraphEditor?.mount)throw new Error(uiText('绘图模块未加载，请刷新后重试。'));
  const key=String(options.storageKey||'dmate:graph-gallery:v1:guest');
  const persistence=options.persistence;
  if(persistence&&typeof persistence.save!=='function')throw new Error('Drawing persistence requires a save function');
  const persistent=!persistence&&options.persistent===true,sessionState=persistence?{}:options.sessionState||{};
  // Online callers retain every feature. Embedded offline owners can omit
  // remote actions entirely, including their controls and event handlers.
  const features={ai:options.features?.ai!==false,upload:options.features?.upload!==false};
  let pages=[],activeId='',editor=null,timer=null,destroyed=false,persistError='',aiAbort=null,aiEpoch=0,exportBusy=false,panelMode='',uploadBusy=false;
  let savedRaw='',restoredGallery=false,exportPreview=null,exportPreviewUrl='',chromeFrame=0,observedView=null,observedViewport=null,observedPalette=null,toolsExpanded=false,deletePending=null;
  let noticeFrame=0,noticeCurrent='',noticeQueue=[],persistNoticeShown='';
  let galleryMetadata={};
  let saveQueue=Promise.resolve(true),pendingSaves=0,queuedRaw='';
  const el=(tag,className,text)=>{const n=doc.createElement(tag);if(className)n.className=className;if(text!==undefined)n.textContent=text;return n;};
  const button=(text,fn,className)=>{const b=el('button',className,text);b.type='button';b.addEventListener('click',event=>{event.stopPropagation();if(!destroyed)void fn();});return b;};
  const sendIcon=()=>{const svg=doc.createElementNS('http://www.w3.org/2000/svg','svg'),path=doc.createElementNS(svg.namespaceURI,'path');
   svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('aria-hidden','true');svg.setAttribute('focusable','false');
   for(const [key,value] of Object.entries({d:'M12 20V4m-7 7 7-7 7 7',fill:'none',stroke:'currentColor','stroke-width':'2.4','stroke-linecap':'round','stroke-linejoin':'round'}))path.setAttribute(key,value);svg.append(path);return svg;};
  const imageIcon=()=>{const svg=doc.createElementNS('http://www.w3.org/2000/svg','svg');
   for(const [key,value] of Object.entries({class:'dmate-lucide-icon',width:20,height:20,viewBox:'0 0 24 24',fill:'none',stroke:'currentColor','stroke-width':1.8,'stroke-linecap':'round','stroke-linejoin':'round','aria-hidden':'true',focusable:'false','data-icon':'image'}))svg.setAttribute(key,String(value));
   for(const [tag,attributes] of [['rect',{width:18,height:18,x:3,y:3,rx:2,ry:2}],['circle',{cx:9,cy:9,r:2}],['path',{d:'m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21'}]]){const part=doc.createElementNS(svg.namespaceURI,tag);for(const [key,value] of Object.entries(attributes))part.setAttribute(key,String(value));svg.append(part);}return svg;};
  const shell=el('section','dmate-drawing-workspace'),top=el('div','ddw-header'),name=el('input','ddw-name');
  name.type='text';name.maxLength=80;name.setAttribute('aria-label','绘图名称');
  const actions=el('div','ddw-page-actions'),body=el('div','ddw-body'),editorHost=el('div','ddw-editor'),rail=el('div','ddw-side-actions'),panel=el('aside','ddw-side-panel'),noticeOwner=el('div','ddw-notice-owner');
  noticeOwner.hidden=true;
  const settingsButton=button('绘图设置',()=>toggleEditorPanel('graphs')),informationButton=button('图形信息',()=>toggleEditorPanel('results'));
  const historyButton=button('历史绘图',()=>togglePanel('history')),aiButton=features.ai?button('AI指导',()=>togglePanel('ai')):null;
  const generateButton=features.ai?button(uiText('AI生成','AI generation'),()=>togglePanel('generate')):null;
  if(aiButton)aiButton.dataset.drawingAiGuidance='true';
  if(generateButton){generateButton.dataset.drawingAiGeneration='true';generateButton.setAttribute('aria-expanded','false');generateButton.setAttribute('aria-busy','false');}
  rail.setAttribute('role','toolbar');rail.setAttribute('aria-label','绘图面板');
  settingsButton.setAttribute('aria-expanded','false');informationButton.setAttribute('aria-expanded','false');
  historyButton.setAttribute('aria-expanded','false');aiButton?.setAttribute('aria-expanded','false');
  const newButton=button('新建空白页',()=>newPage()),exportButton=button('',()=>exportImage(),'ddw-header-export'),uploadButton=features.upload?button('上传',()=>uploadImage(),'ddw-primary ddw-upload-button'):null;
  exportButton.dataset.drawingExport='true';exportButton.title=uiText('以图片形式导出','Export as image');exportButton.setAttribute('aria-label',exportButton.title);exportButton.append(imageIcon());
  if(uploadButton){uploadButton.setAttribute('aria-label','上传');uploadButton.title='上传';}
  actions.append(newButton,historyButton);if(uploadButton)actions.append(uploadButton);top.append(name,actions);rail.append(settingsButton,informationButton);if(aiButton)rail.append(aiButton,generateButton);body.append(editorHost,rail);shell.append(top,body,panel,noticeOwner);host.replaceChildren(shell);host.classList.add('has-drawing-workspace');
  const exportHeader=host.closest('.graph-editor-dialog')?.querySelector(':scope > .graph-editor-dialog-head')||top;
  let requirement='',answer='',answerDocument='',answerRequirement='',nameFollowsGraph=false,aiTask='';
  const active=()=>pages.find(p=>p.id===activeId);
  function showNextNotice(){
   if(destroyed||noticeFrame||noticeCurrent||!noticeQueue.length)return;
   // Mount runs before the outer drawing dialog opens. Defer its first notice
   // and recheck ownership/lifetime before entering the native top layer.
   noticeFrame=win.requestAnimationFrame(()=>{
    noticeFrame=0;const parent=noticeOwner.closest('dialog');
    if(destroyed||!noticeOwner.isConnected||(parent&&!parent.open)){noticeQueue=[];return;}
    const next=noticeQueue.shift();
    if(next.persistent&&next.message!==persistError){showNextNotice();return;}
    if(typeof root.DMateDeleteConfirm?.request!=='function')return;
    noticeCurrent=next.message;if(next.persistent)persistNoticeShown=next.message;
    void root.DMateDeleteConfirm.request(noticeOwner,{title:'绘图提示',body:next.message,noticeOnly:true})
     .finally(()=>{noticeCurrent='';showNextNotice();});
   });
  }
  function setStatus(message){
   if(destroyed)return;
   const value=String(message||persistError||'').trim();if(!value)return;
   const persistent=Boolean(persistError&&value===persistError);
   if((persistent&&persistNoticeShown===value)||noticeCurrent===value||noticeQueue.some(item=>item.message===value))return;
   noticeQueue.push({message:value,persistent});showNextNotice();
  }
  function abortAnswer(){aiEpoch++;aiAbort?.abort();aiAbort=null;aiTask='';}
  function invalidateAnswer(){
   abortAnswer();answer='';answerDocument='';answerRequirement='';
   const ask=panel.querySelector('[data-drawing-guide],[data-math-diagram-generate]');if(ask)ask.setAttribute('aria-busy','false');
   const result=panel.querySelector('.ddw-ai-answer');if(result)result.replaceChildren();
   syncChrome();
  }
  function editorPanel(key){return editorHost.querySelector('.dge-float-panel[data-panel-key="'+key+'"]');}
  function closeEditorPanels(){for(const item of editorHost.querySelectorAll('.dge-floating-actions > details[open]'))item.querySelector(':scope > summary')?.click();}
  function closeTools(){toolsExpanded=false;const palette=editorHost.querySelector('.dge-tool-palette');if(palette)palette.open=false;}
  function dismissPanels(){closeTools();closeEditorPanels();panelMode='';renderPanel();syncChrome();}
  function toggleTools(){if(!active()){newPage();if(!active())return;}const next=!toolsExpanded;editorHost.querySelector('.dge-selection-panel .dge-panel-close')?.click();closeEditorPanels();panelMode='';renderPanel();toolsExpanded=next;syncChrome();}
  function toggleEditorPanel(key){
   if(!active())return;
   closeTools();editorHost.querySelector('.dge-selection-panel .dge-panel-close')?.click();panelMode='';renderPanel();
   editorPanel(key)?.querySelector(':scope > summary')?.click();syncChrome();
  }
  function positionPopover(content,trigger,alignLeft=false){
   if(!content||!trigger)return;
   content.style.visibility='hidden';
   const viewport=win.visualViewport,margin=8,gap=8,viewportLeft=viewport?.offsetLeft||0,viewportTop=viewport?.offsetTop||0;
   let leftEdge=viewportLeft+margin,topEdge=viewportTop+margin;
   let rightEdge=viewportLeft+(viewport?.width||win.innerWidth)-margin,bottomEdge=viewportTop+(viewport?.height||win.innerHeight)-margin;
   // Embedded editors have their own border inside the viewport. Keep every
   // popover inset from that frame instead of letting their edges coincide.
   const hostBox=host.closest('.graph-editor-dialog')?.getBoundingClientRect();
   if(hostBox?.width&&hostBox.height){
    leftEdge=Math.max(leftEdge,hostBox.left+margin);topEdge=Math.max(topEdge,hostBox.top+margin);
    rightEdge=Math.min(rightEdge,hostBox.right-margin);bottomEdge=Math.min(bottomEdge,hostBox.bottom-margin);
   }
   // Translated rail labels can wrap. Keep every row reachable when a
   // popover opens from a button in the first row.
   const triggerBox=trigger.getBoundingClientRect(),railBox=trigger.closest('.ddw-side-actions')?.getBoundingClientRect();
   const anchor=railBox?{left:triggerBox.left,right:triggerBox.right,top:railBox.top,bottom:railBox.bottom}:triggerBox;
   const canvasBox=content.matches('.dge-float-content,.dge-overlay-tools')
    ?editorHost.querySelector('.ddw-canvas-frame')?.getBoundingClientRect():null;
   if(canvasBox?.width&&canvasBox.height){
    const canvasLeft=Math.max(leftEdge,canvasBox.left+margin),canvasRight=Math.min(rightEdge,canvasBox.right-margin);
    if(canvasRight>canvasLeft){leftEdge=canvasLeft;rightEdge=canvasRight;}
    const canvasTop=Math.max(topEdge,canvasBox.top+margin),canvasBottom=Math.min(bottomEdge,canvasBox.bottom-margin);
    const aboveBottom=Math.min(bottomEdge,canvasBox.top-margin),belowTop=Math.max(topEdge,canvasBox.bottom+margin);
    const aboveSpace=Math.max(0,aboveBottom-topEdge),belowSpace=Math.max(0,bottomEdge-belowTop);
    const insideSpace=Math.max(0,Math.min(canvasBottom,anchor.top-gap)-canvasTop,
     canvasBottom-Math.max(canvasTop,anchor.bottom+gap));
    // Prefer the white canvas interior. Short screens can instead use a
    // separate area above/below it, with a gap rather than a crossing border.
    if(insideSpace<120&&aboveSpace>insideSpace&&aboveSpace>=belowSpace)bottomEdge=aboveBottom;
    else if(insideSpace<120&&belowSpace>insideSpace)topEdge=belowTop;
    else if(canvasBottom>canvasTop){topEdge=canvasTop;bottomEdge=canvasBottom;}
   }
   const availableWidth=Math.max(1,rightEdge-leftEdge),availableHeight=Math.max(1,bottomEdge-topEdge);
   const below=bottomEdge-anchor.bottom-gap,above=anchor.top-gap-topEdge;
   const upwards=below<120&&above>below,space=Math.min(availableHeight,Math.max(40,upwards?above:below));
   content.style.maxHeight=space+'px';content.style.maxWidth=availableWidth+'px';
   // A host can create a fixed containing block (for example will-change:
   // transform on the offline main). Measure its origin instead of assuming
   // that fixed left/top are viewport coordinates.
   content.style.left='0px';content.style.right='auto';content.style.top='0px';
   const box=content.getBoundingClientRect(),left=Math.max(leftEdge,Math.min(alignLeft?anchor.left:anchor.right-box.width,rightEdge-box.width));
   const top=Math.max(topEdge,Math.min(upwards?anchor.top-gap-box.height:anchor.bottom+gap,bottomEdge-box.height));
   content.style.left=(left-box.left)+'px';content.style.top=(top-box.top)+'px';content.style.visibility='visible';
  }
  const documentScrolled=event=>{
   if(event.target===observedViewport||event.target?.closest?.('.ddw-side-panel,.dge-float-content,.dge-overlay-tools'))return;
   queueChrome();
  };
  function syncChrome(){
   if(destroyed)return;
   const viewport=editorHost.querySelector('.dge-overlay-viewport'),palette=editorHost.querySelector('.dge-tool-palette');
   // The editor rebuilds its action row while retaining the canvas. Reattach
   // that canvas's existing zoom controls instead of replacing their handlers.
   const view=editorHost.querySelector('.dge-view-controls')||(viewport===observedViewport?observedView:null);
   const topLine=editorHost.querySelector(':scope > .dge-topline');
   if(view&&topLine&&view.parentElement!==topLine)topLine.append(view);
   if(resizeObserver&&observedView!==view){if(observedView)resizeObserver.unobserve(observedView);observedView=view;if(view)resizeObserver.observe(view);}
   if(observedViewport!==viewport){
    if(observedViewport)resizeObserver?.unobserve(observedViewport);
    observedViewport=viewport;
    if(viewport){
     if(!viewport.parentElement.classList.contains('ddw-canvas-frame')){const frame=el('div','ddw-canvas-frame');viewport.before(frame);frame.append(viewport);}
     viewport.style.removeProperty('clip-path');
     resizeObserver?.observe(viewport);
    }
   }
   if(palette&&observedPalette!==palette){
    observedPalette=palette;const trigger=palette.querySelector(':scope > summary');
    trigger?.setAttribute('aria-label','绘图工具');trigger?.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();toggleTools();});
   }
   const empty=!active(),disabled=exportBusy||Boolean(exportPreview);name.disabled=empty||disabled;editorHost.inert=disabled;rail.inert=disabled;
   exportButton.disabled=empty||disabled||!currentDocument().graphs.some(graph=>graph.vertices.length);exportButton.setAttribute('aria-busy',String(exportBusy));
   if(viewport)viewport.inert=empty;
   settingsButton.disabled=empty||disabled;informationButton.disabled=empty||disabled;if(aiButton)aiButton.disabled=disabled;
   if(generateButton){generateButton.disabled=disabled;generateButton.setAttribute('aria-busy',String(aiTask==='generate'));}
   const send=panel.querySelector('[data-drawing-guide],[data-math-diagram-generate]');
   if(send){send.disabled=disabled||Boolean(aiAbort)||(panelMode==='generate'?!requirement.trim():!active());send.setAttribute('aria-busy',String(aiTask===(panelMode==='generate'?'generate':'guide')));}
   shell.classList.toggle('is-empty',empty);
   if(palette){palette.open=toolsExpanded&&!empty;const trigger=palette.querySelector(':scope > summary');trigger?.setAttribute('aria-expanded',String(palette.open));trigger?.setAttribute('aria-disabled',String(disabled));}
   for(const item of editorHost.querySelectorAll('.dge-float-panel')){
    const content=item.querySelector(':scope > .dge-float-content');
    if(content&&!content.querySelector(':scope > .ddw-editor-panel-header')){
     const head=el('div','ddw-editor-panel-header');head.append(el('h3','',item.dataset.panelKey==='graphs'?'绘图设置':'图形信息'));content.prepend(head);
    }
   }
   const editorOpen=Boolean(editorHost.querySelector('.dge-floating-actions > details[open]'));
   const properties=editorHost.querySelector('.dge-selection-panel');
   const propertyOpen=Boolean(properties?.childElementCount);
   settingsButton.setAttribute('aria-expanded',String(Boolean(editorPanel('graphs')?.open)));
   informationButton.setAttribute('aria-expanded',String(Boolean(editorPanel('results')?.open)));
   shell.dataset.panelOpen=String(Boolean(panelMode||editorOpen||propertyOpen||toolsExpanded));
   // The frame never pans. Own these positions through scoped CSS variables
   // so the overlay's standalone inline palette placement cannot compete.
   const origin=body.getBoundingClientRect(),frame=viewport?.parentElement;
   const canvasBox=frame?.getBoundingClientRect()||origin,inset=18,controlsTop=canvasBox.top+inset;
   body.style.setProperty('--ddw-controls-right',Math.max(inset,origin.right-canvasBox.right+inset)+'px');
   body.style.setProperty('--ddw-controls-top',(controlsTop-origin.top)+'px');
   if(palette){const parent=palette.offsetParent?.getBoundingClientRect()||origin;
    body.style.setProperty('--ddw-tools-top',(controlsTop-parent.top)+'px');
    body.style.setProperty('--ddw-tools-left',(canvasBox.left+inset-parent.left)+'px');}
   const toolBox=palette?.querySelector(':scope > summary')?.getBoundingClientRect();
   if(toolBox&&rail.getBoundingClientRect().left<toolBox.right+12)body.style.setProperty('--ddw-controls-top',(toolBox.bottom-origin.top+12)+'px');
   const top=Math.max(rail.getBoundingClientRect().bottom,toolBox?.bottom||0)-origin.top+8;
   body.style.setProperty('--ddw-panel-top',top+'px');
   const propertyOrigin=editorHost.querySelector('.dge-workspace')?.getBoundingClientRect()||origin;
   body.style.setProperty('--ddw-property-top',Math.max(0,origin.top+top-propertyOrigin.top)+'px');
   const visibleBottom=(win.visualViewport?.offsetTop||0)+(win.visualViewport?.height||win.innerHeight);
   body.style.setProperty('--ddw-property-bottom',Math.max(12,propertyOrigin.bottom-visibleBottom+8)+'px');
   body.style.setProperty('--ddw-panel-space',Math.max(90,origin.height-top-10)+'px');
   if(panelMode)positionPopover(panel,panelMode==='history'?historyButton:panelMode==='generate'?generateButton:aiButton);
   for(const [key,trigger] of [['graphs',settingsButton],['results',informationButton]]){const item=editorPanel(key);if(item?.open)positionPopover(item.querySelector(':scope > .dge-float-content'),trigger,key==='graphs'&&win.innerWidth<=900);}
   if(palette?.open)positionPopover(palette.querySelector(':scope > .dge-overlay-tools'),palette.querySelector(':scope > summary'),true);
  }
  function queueChrome(){if(!chromeFrame&&!destroyed)chromeFrame=win.requestAnimationFrame(()=>{chromeFrame=0;syncChrome();});}
  const chromeObserver=new win.MutationObserver(queueChrome);chromeObserver.observe(editorHost,{childList:true,subtree:true});
  const resizeObserver=typeof win.ResizeObserver==='function'?new win.ResizeObserver(queueChrome):null;resizeObserver?.observe(body);
  editorHost.addEventListener('toggle',queueChrome,true);
  editorHost.addEventListener('pointerdown',event=>{if(panelMode&&event.target.closest('.dge-overlay-node,.dge-overlay-edge,.dge-overlay-handle')){panelMode='';renderPanel();}},true);
  const outsidePointer=event=>{
   if(destroyed||exportPreview||deletePending||noticeCurrent||!event.target?.closest)return;
   if(!panelMode&&!toolsExpanded&&!editorHost.querySelector('.dge-floating-actions > details[open]'))return;
   if(event.target.closest('.ddw-side-actions,.ddw-side-panel,.dge-float-content,.dge-tool-palette')||historyButton.contains(event.target))return;
   dismissPanels();
  };
  const escapeKey=event=>{
   if(event.key!=='Escape'||exportPreview||deletePending||noticeCurrent||(!panelMode&&!toolsExpanded&&!editorHost.querySelector('.dge-floating-actions > details[open]')))return;
   event.preventDefault();event.stopPropagation();const focus=panelMode==='history'?historyButton:panelMode==='ai'?aiButton:panelMode==='generate'?generateButton:editorPanel('graphs')?.open?settingsButton:editorPanel('results')?.open?informationButton:editorHost.querySelector('.dge-tool-palette > summary');
   dismissPanels();focus?.focus({preventScroll:true});
  };
  doc.addEventListener('pointerdown',outsidePointer,true);doc.addEventListener('keydown',escapeKey,true);
  win.addEventListener('resize',queueChrome);doc.addEventListener('scroll',documentScrolled,true);win.visualViewport?.addEventListener('resize',queueChrome);win.visualViewport?.addEventListener('scroll',queueChrome);
  function currentDocument(){return editor?.getDocument?.()||active()?.document||emptyDocument();}
  function collect(){const p=active();if(!p)return;const value=clone(currentDocument()),title=caption(name.value);
   const changed=!persistence||fingerprint(p.document)!==fingerprint(value)||p.name!==title;
   p.document=value;p.name=title;if(changed)p.updatedAt=Date.now();}
  function saveFailure(error){
   if(error?.code==='CONFLICT')return uiText('此绘图库已在另一个页面修改，当前绘图仍保留，请重新打开后重试。','This gallery changed in another page. Your current drawing is retained; reopen it and retry.');
   const reason={
    QUOTA_EXCEEDED:uiText('此设备存储空间不足。','This device has insufficient storage space.'),
    TOO_LARGE:uiText('绘图库超过保存大小限制。','The gallery exceeds the storage size limit.'),
    CLOSED:uiText('账号状态已变化，请重新打开离线页面。','The account state changed; reopen the offline page.'),
    STORAGE_BLOCKED:uiText('请关闭旧版离线页面后重试。','Close older offline pages and retry.'),
    KEYSTORE_UNAVAILABLE:uiText('系统密钥库暂时无法使用或已锁定。','The system key store is unavailable or locked.')
   }[error?.code];
   return reason?uiText('绘图未能保存：','The drawing could not be saved: ')+reason+' '+uiText('当前内容仍在本页保留，请重试后再关闭页面。','It remains on this page; retry before closing.')
    :uiText('绘图未能保存，当前内容仍在本页保留，请重试后再关闭页面。','The drawing could not be saved. It remains on this page; retry before closing.');
  }
  function persist(notify=true){
   clearTimeout(timer);timer=null;if(destroyed)return false;
   const payload=JSON.stringify({...galleryMetadata,version:2,activeId,pages});
   // Keep the complete gallery in this owner's page memory even when storage
   // is full. Closing the drawing dialog must not discard that newer draft.
   sessionState.gallery=payload;
   if(persistence){
    if(!pendingSaves&&payload===savedRaw&&!sessionState.galleryDirty)return true;
    if(pendingSaves&&payload===queuedRaw)return false;
    sessionState.galleryDirty=true;queuedRaw=payload;pendingSaves++;
    const snapshot=JSON.parse(payload);
    saveQueue=saveQueue.then(async()=>{
     try{
      if(destroyed)return false;
      const result=await persistence.save(snapshot);
      if(result===false)throw new Error('Drawing save did not commit');
      savedRaw=payload;
      // An older completed write must not acknowledge a newer drawing draft.
      if(sessionState.gallery===payload&&!timer){sessionState.galleryDirty=false;persistError='';persistNoticeShown='';}
      return true;
     }catch(error){
      sessionState.galleryDirty=true;
      persistError=saveFailure(error);
      if(notify&&!destroyed)setStatus();
      return false;
     }finally{pendingSaves--;if(!pendingSaves)queuedRaw='';}
    });
    return false;
   }
   if(payload===savedRaw&&!sessionState.galleryDirty)return true;
   try{if(sessionState.gallerySaveFailed)throw new Error('Guest gallery checkpoint failed');if(persistent)win.localStorage.setItem(key,payload);sessionState.galleryDirty=false;savedRaw=payload;persistError='';persistNoticeShown='';return true;}
   catch(_){sessionState.galleryDirty=true;persistError='此设备存储不足，当前绘图仍在本页保留；请导出图片后再关闭页面。';if(notify)setStatus();return false;}
  }
  async function flush(){
   if(destroyed)return false;
   collect();persist();
   let observed,result;
   do{observed=saveQueue;result=await observed;}while(!destroyed&&observed!==saveQueue);
   return persistence?Boolean(result&&!sessionState.galleryDirty):!sessionState.galleryDirty;
  }
  function schedule(){if(persistence)sessionState.galleryDirty=true;clearTimeout(timer);timer=win.setTimeout(()=>persist(),350);}
  function mountPage(){
   editor?.destroy();editor=null;const p=active(),documentValue=p?.document||emptyDocument();
   name.value=p?.name||'';nameFollowsGraph=false;requirement=p?.requirement||'';answer='';answerDocument='';answerRequirement='';
   const initial=p?blank(p.name):emptyDocument(),url='data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="700"><rect width="100%" height="100%" fill="white"/></svg>');
   if(p&&(!p.viewState||typeof p.viewState!=='object'||Array.isArray(p.viewState)))p.viewState={};
   editor=root.DMateGraphEditor.mount(editorHost,{document:clone(documentValue),initialDocument:initial,originalUrl:url,drawingOnly:true,viewState:p?.viewState,
    onViewChange:()=>{if(!destroyed)schedule();},
    onChange:value=>{if(destroyed)return;const selected=active();if(!selected)return;selected.document=clone(value);selected.updatedAt=Date.now();
     if(nameFollowsGraph&&doc.activeElement!==name&&value.graphs[0]){selected.name=caption(value.graphs[0].name);name.value=selected.name;}
     options.onChange?.(clone(value));invalidateAnswer();schedule();},
    onConfirm:async value=>{const selected=active();if(!selected)return;selected.document=clone(value);selected.name=caption(name.value);selected.updatedAt=Date.now();const saved=persistence?await flush():persist();if(!saved)throw new Error(persistError);if(panelMode==='history')renderPanel();}
   });
   const mountedDocument=currentDocument();if(p)p.document=clone(mountedDocument);
   options.onChange?.(clone(mountedDocument));renderPanel();syncChrome();
  }
  function switchPage(pageId){if(pageId===activeId||!pages.some(p=>p.id===pageId))return;cancelDelete();collect();persist();abortAnswer();activeId=pageId;persist();mountPage();setStatus('');}
  function newPage(){
   if(pages.length>=50){setStatus('最多保留 50 张绘图，请先导出并删除不再需要的历史绘图。');return;}
   cancelDelete();collect();persist();abortAnswer();const pageName=uiText('绘图 '+(pages.length+1),'Drawing '+(pages.length+1)),p={id:id(),name:pageName,document:blank(pageName),requirement:'',createdAt:Date.now(),updatedAt:Date.now()};pages.push(p);activeId=p.id;persist();mountPage();setStatus('');
  }
  function createPageFromDocument(documentValue,pageName,requestText=''){
   if(pages.length>=50)throw new Error('最多保留 50 张绘图，请先导出并删除不再需要的历史绘图。');
   if(!goodDocument(documentValue)||documentValue.graphs.length!==1||!documentValue.graphs[0].vertices.length)throw new Error('生成的数学图结构无效，未创建画板。');
   const normalized=root.DMateGraphEditor.importDocument(documentValue);
   const issues=root.DMateGraphEditor.validateDocument(normalized);
   if(issues.length)throw new Error(issues[0]);
   collect();persist();const title=caption(pageName||normalized.graphs[0].name||uiText('数学图','Math diagram'));
   const page={id:id(),name:title,document:clone(normalized),requirement:String(requestText||'').slice(0,2000),createdAt:Date.now(),updatedAt:Date.now()};
   pages.push(page);activeId=page.id;panelMode='';persist();mountPage();setStatus(uiText('数学图已生成，可以继续编辑。','Mathematical diagram generated. You can continue editing it.'));
   return page.id;
  }
  function togglePanel(mode){if((mode==='ai'||mode==='generate')&&!features.ai)return;closeTools();editorHost.querySelector('.dge-selection-panel .dge-panel-close')?.click();closeEditorPanels();panelMode=panelMode===mode?'':mode;renderPanel();syncChrome();}
  function renderPanel(){
   if((panelMode==='ai'||panelMode==='generate')&&!features.ai)panelMode='';
   if(aiTask==='generate'&&panelMode!=='generate')abortAnswer();
   panel.style.visibility='hidden';panel.hidden=!panelMode;panel.replaceChildren();historyButton.setAttribute('aria-expanded',String(panelMode==='history'));aiButton?.setAttribute('aria-expanded',String(panelMode==='ai'));generateButton?.setAttribute('aria-expanded',String(panelMode==='generate'));
   if(!panelMode){syncChrome();return;}
   const header=el('div','ddw-panel-header');header.append(el('h3','',panelMode==='history'?'历史绘图':panelMode==='generate'?'AI生成':'AI指导'));panel.append(header);
   if(panelMode==='history'){
    const list=el('div','ddw-history-list');
    // The persisted array is the creation order; visiting or editing a page
    // must not move any of the history controls under the user's pointer.
    pages.forEach(p=>{
     const row=el('div','ddw-history-item'+(p.id===activeId?' is-current':'')),open=button(p.name,()=>switchPage(p.id),'ddw-history-open');
     open.setAttribute('data-i18n-content','');
     open.setAttribute('aria-current',String(p.id===activeId));
     const remove=button('',()=>requestRemovePage(p.id,remove),'ddw-history-delete');remove.setAttribute('aria-label',uiText('删除绘图：'+p.name+'（'+p.id+'）','Delete drawing: '+p.name+'（'+p.id+'）'));remove.title=uiText('删除'+p.name,'Delete '+p.name);remove.disabled=Boolean(deletePending);
     row.append(open,remove);list.append(row);
    });if(!pages.length)list.append(el('p','ddw-history-empty','无'));panel.append(list);syncChrome();return;
   }
   const generating=panelMode==='generate',requestLabel=generating?uiText('绘图要求','Diagram request'):uiText('绘图要求（可选）','Diagram request (optional)');
   const label=el('label','ddw-ai-label',requestLabel),input=el('textarea','ddw-ai-requirement');input.rows=3;input.maxLength=2000;input.value=requirement;input.required=generating;input.setAttribute('aria-label',requestLabel);
   input.addEventListener('input',()=>{requirement=input.value;const p=active();if(p){p.requirement=requirement;p.updatedAt=Date.now();schedule();}invalidateAnswer();});label.append(input);
   const actionRow=el('div','ddw-ai-actions');
   const ask=button('',()=>generating?requestGenerate():requestGuide(),'ddw-guide-button');ask.append(sendIcon());
   if(generating){ask.dataset.mathDiagramGenerate='true';ask.setAttribute('aria-label',uiText('请求 AI 生成','Request AI generation'));ask.title=uiText('生成数学图','Generate diagram');}
   else{ask.dataset.drawingGuide='true';ask.setAttribute('aria-label','请求 AI 指导');ask.title='指导当前图形';}
   const result=el('div','ddw-ai-answer');result.setAttribute('data-i18n-content','');result.setAttribute('aria-live','polite');
   actionRow.append(ask);panel.append(label,actionRow,result);
   if(!generating&&answer){
    const renderedAnswer=answer,renderedPage=activeId,renderedRequirement=requirement;
    if(root.DMateAIAnswer?.render)root.DMateAIAnswer.render(result,answer,{isCurrent:()=>!destroyed&&panelMode==='ai'&&activeId===renderedPage&&answer===renderedAnswer&&requirement===renderedRequirement});
    else result.textContent=answer;
   } else if(generating&&aiTask==='generate') {
    result.textContent=uiText('正在生成数学图并自动布局…','Generating and laying out the diagram…');
   }
   syncChrome();
  }
  function syncDeleteButtons(){for(const control of panel.querySelectorAll('.ddw-history-delete'))control.disabled=Boolean(deletePending);}
  function cancelDelete(){deletePending=null;root.DMateDeleteConfirm?.cancel(shell);syncDeleteButtons();}
  function deletionSnapshot(page){return fingerprint({...page,document:page.id===activeId?currentDocument():page.document});}
  async function requestRemovePage(pageId,trigger){
   const page=pages.find(item=>item.id===pageId);if(!page||deletePending||destroyed)return;
   const op={id:pageId,page,activeId,snapshot:deletionSnapshot(page),trigger};deletePending=op;
   const settings={title:'删除这个绘图？',body:'删除后无法恢复。\n'+page.name,content:page.name,confirmText:'删除绘图',confirmTone:'danger'};
   try{
    if(typeof options.confirmDelete!=='function'&&typeof root.DMateDeleteConfirm?.request!=='function')throw new Error(uiText('删除确认界面未加载，请刷新后重试。'));
    const confirmation=typeof options.confirmDelete==='function'?options.confirmDelete(settings):root.DMateDeleteConfirm?.request(shell,settings);
    syncDeleteButtons();const confirmed=await confirmation;
    const current=pages.find(item=>item.id===op.id);
    if(!confirmed||destroyed||deletePending!==op||activeId!==op.activeId||current!==op.page||deletionSnapshot(current)!==op.snapshot)return;
    removePage(op.id);
   }catch(error){if(!destroyed&&deletePending===op)setStatus(error?.message||'无法确认删除，请重试。');}
   finally{if(deletePending===op){deletePending=null;if(!destroyed){syncDeleteButtons();(trigger?.isConnected?trigger:historyButton).focus({preventScroll:true});}}}
  }
  function removePage(pageId){
   const index=pages.findIndex(p=>p.id===pageId);if(index<0)return;
   if(pageId===activeId){abortAnswer();editor?.destroy();editor=null;pages.splice(index,1);activeId=pages[Math.min(index,pages.length-1)]?.id||'';persist();mountPage();}
   else{collect();pages.splice(index,1);persist();renderPanel();}
   setStatus('');
  }
  async function requestGuide(){
   if(!features.ai||aiAbort||destroyed||!active())return;collect();persist();
   const snapshot=clone(currentDocument()),snapshotKey=fingerprint(snapshot),request=requirement,selected=activeId,epoch=++aiEpoch;
   const controller=new win.AbortController();aiAbort=controller;aiTask='guide';answer='';renderPanel();setStatus('');
   try{
    const response=await win.fetch('/drawing/guide',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({document:snapshot,requirement:request,language:root.DMateI18n?.getLanguage?.()||doc.documentElement.lang||'zh-CN'}),signal:controller.signal});
    let result;try{result=await response.json();}catch(_){throw new Error(uiText('AI 返回内容无效，请重试。'));}
    if(!response.ok||result.ok!==true||typeof result.answer!=='string'||!result.answer.trim())throw new Error(result.error||'AI 指导暂时失败，请重试。');
    if(destroyed||epoch!==aiEpoch||activeId!==selected||fingerprint(currentDocument())!==snapshotKey||requirement!==request)return;
    answer=result.answer;answerDocument=snapshotKey;answerRequirement=request;setStatus('');
   }catch(error){if(!destroyed&&epoch===aiEpoch&&error?.name!=='AbortError')setStatus(error?.message||'AI 指导失败，请重试。');}
   finally{if(epoch===aiEpoch){aiAbort=null;aiTask='';if(!destroyed)renderPanel();}}
  }
  async function requestGenerate(){
   if(!features.ai||aiAbort||destroyed||panelMode!=='generate')return;
   const requestedRequirement=requirement.trim();if(!requestedRequirement)return;
   const request=requestedRequirement;
   if(pages.length>=50){setStatus('最多保留 50 张绘图，请先导出并删除不再需要的历史绘图。');return;}
   if(!root.DMateMathDiagram?.generate){setStatus(uiText('数学图生成模块未加载，请刷新后重试。','The diagram generator is not loaded. Refresh and try again.'));return;}
   const selected=activeId,epoch=++aiEpoch,controller=new win.AbortController();aiAbort=controller;aiTask='generate';answer='';renderPanel();setStatus('');
   try{
    const result=await root.DMateMathDiagram.generate(request,root.DMateI18n?.getLanguage?.()||doc.documentElement.lang||'zh-CN',controller.signal);
    if(destroyed||epoch!==aiEpoch||panelMode!=='generate'||activeId!==selected||requirement.trim()!==requestedRequirement)return;
    createPageFromDocument(result.document,result.title,requestedRequirement);
   }catch(error){
    if(!destroyed&&epoch===aiEpoch&&error?.name!=='AbortError')setStatus(error?.message||uiText('数学图生成失败，请重试。','Diagram generation failed. Please try again.'));
   }finally{if(epoch===aiEpoch){aiAbort=null;aiTask='';if(!destroyed)renderPanel();}}
  }
  async function makeImage(){
   if(!active())throw new Error(uiText('请先新建空白页。'));
   if(!root.DMateDrawingExport?.pngBlob)throw new Error(uiText('导出模块未加载，请刷新后重试。'));
   if(!currentDocument().graphs.some(g=>g.vertices.length))throw new Error(uiText('请先在空白页添加顶点和边'));
   const svg=editor?.getDrawingSvg?.(),document=root.DMateDrawingExport.documentForImage(currentDocument(),svg);
   return {blob:await root.DMateDrawingExport.pngBlob(svg),document};
  }
  function busy(value){exportBusy=value;const disabled=value||Boolean(exportPreview);exportButton.disabled=disabled;if(uploadButton)uploadButton.disabled=disabled;newButton.disabled=disabled;historyButton.disabled=disabled;panel.inert=disabled;syncChrome();}
  function closeExportPreview(){
   exportPreview?.remove();exportPreview=null;
   if(exportPreviewUrl){win.URL.revokeObjectURL(exportPreviewUrl);exportPreviewUrl='';}
   if(!destroyed){busy(exportBusy);exportButton.focus({preventScroll:true});}
  }
  function showExportPreview(blob,pageName){
   closeExportPreview();exportPreviewUrl=win.URL.createObjectURL(blob);
   exportPreview=el('section','ddw-export-preview');exportPreview.setAttribute('role','dialog');exportPreview.setAttribute('aria-modal','true');exportPreview.setAttribute('aria-label','导出绘图');
   const header=el('div','ddw-export-header'),close=button('',closeExportPreview,'ddw-export-close');close.setAttribute('aria-label','关闭图片预览');
   header.append(el('h3','','导出绘图'),close);
   const tip=el('p','ddw-export-tip',uiText('网页无法直接写入手机相册。请长按图片保存，或选择系统分享/保存。','A website cannot write directly to Photos. Touch and hold the image to save it, or choose system share/save.'));
   tip.style.cssText='margin:0;font-size:13px;line-height:1.5;color:var(--text-secondary)';
   const image=el('img','ddw-export-image');image.src=exportPreviewUrl;image.alt=uiText(pageName+'，绘图导出图片','Exported drawing: '+pageName);
   const link=el('a','ddw-export-download','下载图片');link.href=exportPreviewUrl;link.download=root.DMateDrawingExport.pngFilename(pageName);
   link.addEventListener('click',()=>{tip.textContent=uiText('已发起图片下载','Image download started');});
   exportPreview.append(header,tip,image,link);
   if(typeof win.File==='function'&&typeof win.navigator.share==='function'){
    const file=new win.File([blob],root.DMateDrawingExport.pngFilename(pageName),{type:'image/png'});
    let supported=true;try{supported=typeof win.navigator.canShare!=='function'||win.navigator.canShare({files:[file]});}catch(_){supported=false;}
    if(supported)exportPreview.append(button('系统分享/保存',async()=>{
     try{await win.navigator.share({files:[file]});tip.textContent=uiText('请在系统操作中选择保存位置','Choose a save location in the system options.');}
     catch(error){if(error?.name!=='AbortError')tip.textContent=uiText('系统分享不可用，请长按图片保存','System sharing is unavailable. Touch and hold the image to save it.');}
    },'ddw-export-share'));
   }
   shell.append(exportPreview);
   exportPreview.addEventListener('keydown',event=>{
    if(event.key==='Escape'){event.preventDefault();event.stopPropagation();closeExportPreview();}
    if(event.key==='Tab'){
     const controls=[close,link,...exportPreview.querySelectorAll('.ddw-export-share')],index=controls.indexOf(doc.activeElement),direction=event.shiftKey?-1:1;
     event.preventDefault();controls[(index+direction+controls.length)%controls.length].focus();
    }
   });busy(exportBusy);close.focus({preventScroll:true});
  }
  async function exportImage(){if(exportBusy)return;busy(true);try{collect();persist();const metadata={name:caption(name.value)},{blob}=await makeImage();if(destroyed)return;if(typeof options.onExport==='function')await options.onExport(blob,metadata);else await root.DMateDrawingExport.save(blob,metadata.name,{document:doc,mobilePreview:showExportPreview});if(!destroyed)setStatus('');}catch(error){if(!destroyed)setStatus(error?.message||'图片导出失败。');}finally{if(!destroyed)busy(false);}}
  async function uploadImage(){
   if(!features.upload||exportBusy)return;busy(true);uploadBusy=true;
   try{if(typeof options.onUpload!=='function')throw new Error(uiText('上传功能未就绪，请刷新后重试。'));collect();if(persistence){if(!await flush())throw new Error(persistError);}else persist();const pageName=caption(name.value),requirements=requirement,{blob,document}=await makeImage();if(destroyed)return;await options.onUpload(blob,{name:pageName,document,requirements});if(!destroyed){setStatus('');options.onClose?.();}}
   catch(error){if(!destroyed)setStatus(error?.message||'绘图上传失败，请重试。');}
   finally{uploadBusy=false;if(!destroyed)busy(false);}
  }
  name.addEventListener('input',()=>{const p=active();if(p){nameFollowsGraph=true;p.name=caption(name.value);p.updatedAt=Date.now();
   const graph=editor?.getDocument?.().graphs[0];
   if(graph&&graph.name!==p.name){editor.model?.renameGraph(graph.id,p.name);editor.refresh?.();}
   schedule();}});
  try{
   const draft=persistent&&sessionState.galleryDirty?sessionState.gallery:null;
   const initial=persistence?.initialGallery;
   const raw=persistence?(typeof initial==='string'?initial:initial?JSON.stringify(initial):sessionState.gallery)
    :draft||(persistent?win.localStorage.getItem(key):sessionState.gallery),value=raw?JSON.parse(raw):null;
   if((value?.version===1||value?.version===2)&&Array.isArray(value.pages)){
    restoredGallery=true;
    galleryMetadata={...value};
    for(const field of ['version','activeId','pages'])delete galleryMetadata[field];
    pages=value.pages.filter(p=>p&&typeof p.id==='string'&&goodDocument(p.document)).slice(0,50).map(p=>({...p,name:caption(p.name),requirement:String(p.requirement||'').slice(0,2000),updatedAt:Number(p.updatedAt)||0}));
    const ids=new Set();pages=pages.filter(p=>{if(ids.has(p.id))return false;ids.add(p.id);return true;});activeId=pages.some(p=>p.id===value.activeId)?value.activeId:pages[0]?.id||'';savedRaw=JSON.stringify({...galleryMetadata,version:value.version,activeId,pages});
   }
  }catch(_){persistError='历史绘图暂时无法读取，当前绘图仍可编辑和导出。';}
  if(!restoredGallery){
   const legacy=meaningfulDocument(options.legacyDocument)?clone(options.legacyDocument):null;
   if(legacy){pages=[{id:id(),name:'我的图形',document:legacy,requirement:'',createdAt:Date.now(),updatedAt:Date.now()}];activeId=pages[0].id;}
  }
  // Older blank pages kept the generic graph title after receiving a page number.
  if(restoredGallery)for(const p of pages)if(/^绘图\s*\d+$/.test(p.name)&&p.document.graphs.length===1&&p.document.graphs[0].name==='我的图形')p.document.graphs[0].name=p.name;
  // Older drawing documents could contain several subgraphs. Every graph
  // becomes its own accessible page now that subgraph management is removed.
  pages=pages.flatMap(p=>p.document.graphs.length===1?[p]:p.document.graphs.map((graph,index)=>({...p,id:index?id():p.id,
   name:caption(graph.name||p.name+' '+(index+1)),document:{...clone(p.document),graphs:[clone(graph)]}})));
  if(!pages.length&&options.createBlankIfEmpty===true)newPage();
  else{mountPage();persist();}
  // Attach external chrome only after the editor mounted successfully, so a
  // failed mount cannot leave a drawing action in the shared image dialog.
  exportHeader.classList.add('has-drawing-header-export');exportHeader.insertBefore(exportButton,exportHeader.querySelector(':scope > .graph-editor-close-dot'));
  const pageHide=()=>{collect();persist(false);};win.addEventListener('pagehide',pageHide);
  return{getDocument:()=>clone(currentDocument()),getPages:()=>clone(pages),isBusy:()=>uploadBusy,createPageFromDocument,flush,
   hasUnsavedChanges:()=>Boolean(sessionState.galleryDirty||pendingSaves),
   fitView:()=>editor?.fitView?.(),
   destroy(){if(destroyed)return;collect();persist(false);destroyed=true;noticeQueue=[];if(noticeFrame)win.cancelAnimationFrame(noticeFrame);root.DMateDeleteConfirm?.cancel(noticeOwner);cancelDelete();closeExportPreview();clearTimeout(timer);if(chromeFrame)win.cancelAnimationFrame(chromeFrame);chromeObserver.disconnect();resizeObserver?.disconnect();abortAnswer();doc.removeEventListener('pointerdown',outsidePointer,true);doc.removeEventListener('keydown',escapeKey,true);doc.removeEventListener('scroll',documentScrolled,true);win.removeEventListener('resize',queueChrome);win.visualViewport?.removeEventListener('resize',queueChrome);win.visualViewport?.removeEventListener('scroll',queueChrome);win.removeEventListener('pagehide',pageHide);editor?.destroy();exportButton.remove();if(!exportHeader.querySelector(':scope > .ddw-header-export'))exportHeader.classList.remove('has-drawing-header-export');host.replaceChildren();host.classList.remove('has-drawing-workspace');}};
 }
 root.DMateDrawingWorkspace={mount,blankDocument:blank};
})(typeof window!=='undefined'?window:globalThis);
