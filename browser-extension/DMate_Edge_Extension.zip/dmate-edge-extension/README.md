# DMate for Microsoft Edge

This is a native Edge Side Panel chat client.

## Install locally

1. Extract this ZIP.
2. Open `edge://extensions` in Microsoft Edge.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select the extracted `dmate-edge-extension` folder.
6. Pin DMate to the toolbar if desired, then click its icon.

## Included

- Native Edge Side Panel opened from the toolbar.
- Dark DMate-style header, conversation area, question marker, and rounded composer.
- Text chat through the existing `POST /chat` endpoint.
- Local conversation persistence using `chrome.storage.local`.
- Enter to send; Shift+Enter for a new line.
- Minimal permissions: `sidePanel`, `storage`, and host access to the DMate production API.

## Scope

The extension runs as a local extension page and calls the DMate chat API in guest mode. It does not embed or redirect the full website into the side panel. The current DMate API uses same-origin HttpOnly session cookies and does not provide a general third-party Bearer-token account API, so this first build does not sign in to DMate accounts or access cloud-synced chat history. Conversations are stored locally in this browser. The question marker is a local UI label and does not add an item to the website's formal question bank.

For account login, image recognition, notebooks, graph tools, and cross-device sync, open the full DMate website from the menu.

This is a local development package, not yet an Edge Add-ons store submission. Store artwork, screenshots, privacy disclosures, and listing text still need preparation.
